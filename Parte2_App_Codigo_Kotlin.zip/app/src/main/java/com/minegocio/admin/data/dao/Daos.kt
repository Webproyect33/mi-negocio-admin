package com.minegocio.admin.data.dao

import androidx.room.*
import com.minegocio.admin.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductoDao {
    @Query("""
        SELECT p.*, c.nombre as categoriaNombre 
        FROM productos p 
        LEFT JOIN categorias c ON p.categoriaId = c.id 
        ORDER BY p.id DESC
    """)
    fun getAllProductosConCategoria(): Flow<List<ProductoConCategoria>>

    @Query("SELECT * FROM productos WHERE categoriaId = :catId")
    suspend fun getProductosByCategoria(catId: Int): List<Producto>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducto(producto: Producto): Long

    @Update
    suspend fun updateProducto(producto: Producto)

    @Delete
    suspend fun deleteProducto(producto: Producto)
}

@Dao
interface CategoriaDao {
    @Query("SELECT * FROM categorias ORDER BY nombre ASC")
    fun getAllCategorias(): Flow<List<Categoria>>

    @Query("SELECT * FROM categorias WHERE LOWER(nombre) = LOWER(:nombre) LIMIT 1")
    suspend fun getCategoriaByNombre(nombre: String): Categoria?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCategoria(categoria: Categoria): Long

    @Delete
    suspend fun deleteCategoria(categoria: Categoria)
}

@Dao
interface VendedoraDao {
    @Query("SELECT * FROM vendedoras ORDER BY nombre ASC")
    fun getAllVendedoras(): Flow<List<Vendedora>>

    @Query("SELECT * FROM vendedoras WHERE LOWER(nombre) = LOWER(:nombre) LIMIT 1")
    suspend fun getVendedoraByNombre(nombre: String): Vendedora?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertVendedora(vendedora: Vendedora): Long

    @Delete
    suspend fun deleteVendedora(vendedora: Vendedora)
}

@Dao
interface InformeDao {
    @Transaction
    @Query("SELECT * FROM informes ORDER BY fecha DESC")
    fun getAllInformesConDetalles(): Flow<List<InformeConDetalles>>

    @Transaction
    @Query("SELECT * FROM informes WHERE fecha BETWEEN :startDate AND :endDate ORDER BY fecha DESC")
    suspend fun getInformesBetweenDates(startDate: Long, endDate: Long): List<InformeConDetalles>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInforme(informe: Informe): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDetalles(detalles: List<DetalleInforme>)

    @Transaction
    suspend fun insertInformeCompleto(informe: Informe, detalles: List<DetalleInforme>): Long {
        val informeId = insertInforme(informe).toInt()
        val detallesConId = detalles.map { it.copy(informeId = informeId) }
        insertDetalles(detallesConId)
        return informeId.toLong()
    }

    @Delete
    suspend fun deleteInforme(informe: Informe)
}
