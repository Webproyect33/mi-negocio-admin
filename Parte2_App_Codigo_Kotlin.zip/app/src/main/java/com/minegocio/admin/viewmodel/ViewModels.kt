package com.minegocio.admin.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.minegocio.admin.data.entity.*
import com.minegocio.admin.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// --- ViewModel de Productos ---
class ProductoViewModel(
    private val productoRepo: ProductoRepository,
    private val categoriaRepo: CategoriaRepository
) : ViewModel() {

    val productos: StateFlow<List<ProductoConCategoria>> = productoRepo.allProductos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categorias: StateFlow<List<Categoria>> = categoriaRepo.allCategorias
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun guardarProducto(
        nombre: String,
        precioCompraStr: String,
        precioVentaStr: String,
        cantidadStr: String,
        categoriaId: Int?,
        formato: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (nombre.isBlank()) {
            onError("El nombre del producto es obligatorio")
            return
        }
        val precioCompra = precioCompraStr.toDoubleOrNull()
        if (precioCompra == null || precioCompra < 0) {
            onError("Ingrese un precio de compra válido")
            return
        }
        val precioVenta = precioVentaStr.toDoubleOrNull()
        if (precioVenta == null || precioVenta < 0) {
            onError("Ingrese un precio de venta válido")
            return
        }
        val cantidad = cantidadStr.toIntOrNull()
        if (cantidad == null || cantidad < 0) {
            onError("Ingrese una cantidad válida")
            return
        }
        if (categoriaId == null) {
            onError("Seleccione una categoría")
            return
        }
        if (formato.isBlank()) {
            onError("Seleccione un formato")
            return
        }

        viewModelScope.launch {
            try {
                productoRepo.insertProducto(
                    Producto(
                        nombre = nombre.trim(),
                        precioCompra = precioCompra,
                        precioVenta = precioVenta,
                        cantidad = cantidad,
                        categoriaId = categoriaId,
                        formato = formato
                    )
                )
                onSuccess()
            } catch (e: Exception) {
                onError("Error al guardar: ${e.localizedMessage}")
            }
        }
    }

    fun eliminarProducto(producto: Producto) {
        viewModelScope.launch {
            productoRepo.deleteProducto(producto)
        }
    }
}

// --- ViewModel de Categorías ---
class CategoriaViewModel(private val categoriaRepo: CategoriaRepository) : ViewModel() {
    val categorias: StateFlow<List<Categoria>> = categoriaRepo.allCategorias
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun agregarCategoria(nombre: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = categoriaRepo.insertCategoria(nombre)
            result.fold(
                onSuccess = { onSuccess() },
                onFailure = { onError(it.message ?: "Error al agregar categoría") }
            )
        }
    }

    fun eliminarCategoria(categoria: Categoria, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = categoriaRepo.deleteCategoria(categoria)
            result.fold(
                onSuccess = { onSuccess() },
                onFailure = { onError(it.message ?: "No se pudo eliminar la categoría") }
            )
        }
    }
}

// --- ViewModel de Vendedoras ---
class VendedoraViewModel(private val vendedoraRepo: VendedoraRepository) : ViewModel() {
    val vendedoras: StateFlow<List<Vendedora>> = vendedoraRepo.allVendedoras
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun agregarVendedora(nombre: String, contrasena: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = vendedoraRepo.insertVendedora(nombre, contrasena)
            result.fold(
                onSuccess = { onSuccess() },
                onFailure = { onError(it.message ?: "Error al agregar vendedora") }
            )
        }
    }

    fun eliminarVendedora(vendedora: Vendedora) {
        viewModelScope.launch {
            vendedoraRepo.deleteVendedora(vendedora)
        }
    }
}

// --- ViewModel de Informes y Sacar Cuentas ---
class InformeViewModel(
    private val informeRepo: InformeRepository,
    private val vendedoraRepo: VendedoraRepository
) : ViewModel() {

    val informes: StateFlow<List<InformeConDetalles>> = informeRepo.allInformes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vendedoras: StateFlow<List<Vendedora>> = vendedoraRepo.allVendedoras
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun eliminarInforme(informe: Informe) {
        viewModelScope.launch {
            informeRepo.deleteInforme(informe)
        }
    }

    fun registrarInforme(
        vendedoraId: Int,
        vendedoraNombre: String,
        items: List<DetalleInforme>,
        onSuccess: () -> Unit
    ) {
        val total = items.sumOf { it.precioUnitario * it.cantidad }
        val informe = Informe(
            vendedoraId = vendedoraId,
            vendedoraNombre = vendedoraNombre,
            fecha = System.currentTimeMillis(),
            total = total
        )
        viewModelScope.launch {
            informeRepo.insertInforme(informe, items)
            onSuccess()
        }
    }
}
