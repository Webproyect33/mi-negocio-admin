package com.minegocio.admin

import android.app.Application
import com.minegocio.admin.data.database.AppDatabase
import com.minegocio.admin.data.repository.CategoriaRepository
import com.minegocio.admin.data.repository.InformeRepository
import com.minegocio.admin.data.repository.ProductoRepository
import com.minegocio.admin.data.repository.VendedoraRepository

class MiNegocioApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val productoRepository by lazy { ProductoRepository(database.productoDao()) }
    val categoriaRepository by lazy { CategoriaRepository(database.categoriaDao(), database.productoDao()) }
    val vendedoraRepository by lazy { VendedoraRepository(database.vendedoraDao()) }
    val informeRepository by lazy { InformeRepository(database.informeDao()) }
}
