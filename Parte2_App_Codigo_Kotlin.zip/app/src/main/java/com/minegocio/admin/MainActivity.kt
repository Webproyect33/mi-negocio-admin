package com.minegocio.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.minegocio.admin.navigation.Screen
import com.minegocio.admin.navigation.bottomNavItems
import com.minegocio.admin.ui.screens.*
import com.minegocio.admin.ui.theme.MiNegocioTheme
import com.minegocio.admin.viewmodel.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as MiNegocioApp

        setContent {
            MiNegocioTheme {
                val navController = rememberNavController()

                val productoViewModel: ProductoViewModel = viewModel {
                    ProductoViewModel(app.productoRepository, app.categoriaRepository)
                }
                val categoriaViewModel: CategoriaViewModel = viewModel {
                    CategoriaViewModel(app.categoriaRepository)
                }
                val vendedoraViewModel: VendedoraViewModel = viewModel {
                    VendedoraViewModel(app.vendedoraRepository)
                }
                val informeViewModel: InformeViewModel = viewModel {
                    InformeViewModel(app.informeRepository, app.vendedoraRepository)
                }

                val currentBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = currentBackStackEntry?.destination?.route
                val showBottomBar = currentRoute != Screen.Splash.route

                Scaffold(
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                bottomNavItems.forEach { item ->
                                    val isSelected = currentRoute == item.route
                                    NavigationBarItem(
                                        icon = { item.icon?.let { Icon(it, contentDescription = item.title) } },
                                        label = { Text(item.title) },
                                        selected = isSelected,
                                        onClick = {
                                            if (currentRoute != item.route) {
                                                navController.navigate(item.route) {
                                                    popUpTo(Screen.Home.route) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Splash.route,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // 1. Splash Screen
                        composable(Screen.Splash.route) {
                            SplashScreen(
                                onNavigateToHome = {
                                    navController.navigate(Screen.Home.route) {
                                        popUpTo(Screen.Splash.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // 2. Pantalla Principal (Productos)
                        composable(Screen.Home.route) {
                            val productos by productoViewModel.productos.collectAsState()
                            HomeScreen(
                                productos = productos,
                                onAddClick = { navController.navigate(Screen.AddProduct.route) }
                            )
                        }

                        // 3. Agregar Producto
                        composable(Screen.AddProduct.route) {
                            val categorias by productoViewModel.categorias.collectAsState()
                            AddProductScreen(
                                categorias = categorias,
                                onSaveProduct = { nom, pc, pv, cant, catId, fmt, onSucc, onErr ->
                                    productoViewModel.guardarProducto(nom, pc, pv, cant, catId, fmt, onSucc, onErr)
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // 4. Categorías
                        composable(Screen.Categories.route) {
                            val categorias by categoriaViewModel.categorias.collectAsState()
                            CategoriesScreen(
                                categorias = categorias,
                                onAddCategoria = { nom, onSucc, onErr ->
                                    categoriaViewModel.agregarCategoria(nom, onSucc, onErr)
                                },
                                onDeleteCategoria = { cat, onSucc, onErr ->
                                    categoriaViewModel.eliminarCategoria(cat, onSucc, onErr)
                                }
                            )
                        }

                        // 5. Vendedoras
                        composable(Screen.Vendedoras.route) {
                            val vendedoras by vendedoraViewModel.vendedoras.collectAsState()
                            VendedorasScreen(
                                vendedoras = vendedoras,
                                onAddVendedora = { nom, pass, onSucc, onErr ->
                                    vendedoraViewModel.agregarVendedora(nom, pass, onSucc, onErr)
                                },
                                onDeleteVendedora = { v ->
                                    vendedoraViewModel.eliminarVendedora(v)
                                }
                            )
                        }

                        // 6. Informes
                        composable(Screen.Informes.route) {
                            val informes by informeViewModel.informes.collectAsState()
                            InformesScreen(
                                informes = informes,
                                onDeleteInforme = { inf -> informeViewModel.eliminarInforme(inf) },
                                onNavigateToCuentas = { navController.navigate(Screen.SacarCuentas.route) }
                            )
                        }

                        // 7. Sacar Cuentas
                        composable(Screen.SacarCuentas.route) {
                            val informes by informeViewModel.informes.collectAsState()
                            val vendedoras by informeViewModel.vendedoras.collectAsState()
                            SacarCuentasScreen(
                                informes = informes,
                                vendedoras = vendedoras
                            )
                        }
                    }
                }
            }
        }
    }
}
