package com.minegocio.admin.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector? = null) {
    object Splash : Screen("splash", "Splash")
    object Home : Screen("home", "Productos", Icons.Default.Inventory2)
    object AddProduct : Screen("add_product", "Agregar", Icons.Default.AddCircle)
    object Categories : Screen("categories", "Categorías", Icons.Default.Category)
    object Vendedoras : Screen("vendedoras", "Vendedoras", Icons.Default.People)
    object Informes : Screen("informes", "Informes", Icons.Default.Description)
    object SacarCuentas : Screen("sacar_cuentas", "Sacar Cuentas", Icons.Default.Calculate)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.AddProduct,
    Screen.Categories,
    Screen.Vendedoras,
    Screen.Informes
)
