package com.minegocio.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minegocio.admin.data.entity.Categoria
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(
    categorias: List<Categoria>,
    onAddCategoria: (nombre: String, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit,
    onDeleteCategoria: (categoria: Categoria, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var nuevaCategoriaNombre by remember { mutableStateOf("") }
    var categoriaAEliminar by remember { mutableStateOf<Categoria?>(null) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Mis Categorías", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D47A1),
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp)
        ) {
            // Formulario Agregar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = nuevaCategoriaNombre,
                    onValueChange = { nuevaCategoriaNombre = it },
                    placeholder = { Text("Nueva categoría...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
                Button(
                    onClick = {
                        onAddCategoria(
                            nuevaCategoriaNombre,
                            {
                                nuevaCategoriaNombre = ""
                                scope.launch { snackbarHostState.showSnackbar("Categoría agregada exitosamente") }
                            },
                            { errorMsg ->
                                scope.launch { snackbarHostState.showSnackbar(errorMsg) }
                            }
                        )
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B)),
                    modifier = Modifier.height(56.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Agregar")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Categorías Registradas (${categorias.size})",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155),
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(categorias) { cat ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = cat.nombre,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF0F172A)
                            )
                            IconButton(onClick = { categoriaAEliminar = cat }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Eliminar",
                                    tint = Color(0xFFD32F2F)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Diálogo de Confirmación
    categoriaAEliminar?.let { cat ->
        AlertDialog(
            onDismissRequest = { categoriaAEliminar = null },
            title = { Text("Eliminar Categoría") },
            text = { Text("¿Estás seguro de que deseas eliminar la categoría '${cat.nombre}'?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val toDelete = cat
                        categoriaAEliminar = null
                        onDeleteCategoria(
                            toDelete,
                            {
                                scope.launch { snackbarHostState.showSnackbar("Categoría eliminada") }
                            },
                            { errorMsg ->
                                scope.launch { snackbarHostState.showSnackbar(errorMsg) }
                            }
                        )
                    }
                ) {
                    Text("Eliminar", color = Color(0xFFD32F2F))
                }
            },
            dismissButton = {
                TextButton(onClick = { categoriaAEliminar = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
