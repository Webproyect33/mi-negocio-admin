package com.minegocio.admin.data.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(
    tableName = "productos",
    foreignKeys = [
        ForeignKey(
            entity = Categoria::class,
            parentColumns = ["id"],
            childColumns = ["categoriaId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["categoriaId"])]
)
data class Producto(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val precioCompra: Double,
    val precioVenta: Double,
    val cantidad: Int,
    val categoriaId: Int,
    val formato: String
)

@Entity(tableName = "categorias")
data class Categoria(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String
)

@Entity(tableName = "vendedoras")
data class Vendedora(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val contrasena: String
)

@Entity(tableName = "informes")
data class Informe(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vendedoraId: Int,
    val vendedoraNombre: String,
    val fecha: Long,
    val total: Double
)

@Entity(
    tableName = "detalle_informe",
    foreignKeys = [
        ForeignKey(
            entity = Informe::class,
            parentColumns = ["id"],
            childColumns = ["informeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["informeId"])]
)
data class DetalleInforme(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val informeId: Int,
    val productoNombre: String,
    val precioUnitario: Double,
    val cantidad: Int
)

data class InformeConDetalles(
    @Embedded val informe: Informe,
    @Relation(
        parentColumn = "id",
        entityColumn = "informeId"
    )
    val detalles: List<DetalleInforme>
)

data class ProductoConCategoria(
    @Embedded val producto: Producto,
    val categoriaNombre: String
)
