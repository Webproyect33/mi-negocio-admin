package com.minegocio.admin.data.repository

import com.minegocio.admin.data.dao.*
import com.minegocio.admin.data.entity.*
import kotlinx.coroutines.flow.Flow

class ProductoRepository(private val productoDao: ProductoDao) {
    val allProductos: Flow<List<ProductoConCategoria>> = productoDao.getAllProductosConCategoria()

    suspend fun insertProducto(producto: Producto): Long {
        return productoDao.insertProducto(producto)
    }

    suspend fun deleteProducto(producto: Producto) {
        productoDao.deleteProducto(producto)
    }
}

class CategoriaRepository(
    private val categoriaDao: CategoriaDao,
    private val productoDao: ProductoDao
) {
    val allCategorias: Flow<List<Categoria>> = categoriaDao.getAllCategorias()

    suspend fun insertCategoria(nombre: String): Result<Long> {
        val trimmed = nombre.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(Exception("El nombre no puede estar vacío"))
        }
        val exists = categoriaDao.getCategoriaByNombre(trimmed)
        if (exists != null) {
            return Result.failure(Exception("Ya existe una categoría con este nombre"))
        }
        val id = categoriaDao.insertCategoria(Categoria(nombre = trimmed))
        return Result.success(id)
    }

    suspend fun deleteCategoria(categoria: Categoria): Result<Unit> {
        val productos = productoDao.getProductosByCategoria(categoria.id)
        if (productos.isNotEmpty()) {
            return Result.failure(Exception("No se puede eliminar la categoría porque tiene productos asignados."))
        }
        categoriaDao.deleteCategoria(categoria)
        return Result.success(Unit)
    }
}

class VendedoraRepository(private val vendedoraDao: VendedoraDao) {
    val allVendedoras: Flow<List<Vendedora>> = vendedoraDao.getAllVendedoras()

    suspend fun insertVendedora(nombre: String, contrasena: String): Result<Long> {
        val trimmed = nombre.trim()
        if (trimmed.isEmpty() || contrasena.trim().isEmpty()) {
            return Result.failure(Exception("Nombre y contraseña son obligatorios"))
        }
        val exists = vendedoraDao.getVendedoraByNombre(trimmed)
        if (exists != null) {
            return Result.failure(Exception("Ya existe una vendedora con este nombre"))
        }
        val id = vendedoraDao.insertVendedora(Vendedora(nombre = trimmed, contrasena = contrasena.trim()))
        return Result.success(id)
    }

    suspend fun deleteVendedora(vendedora: Vendedora) {
        vendedoraDao.deleteVendedora(vendedora)
    }
}

class InformeRepository(private val informeDao: InformeDao) {
    val allInformes: Flow<List<InformeConDetalles>> = informeDao.getAllInformesConDetalles()

    suspend fun insertInforme(informe: Informe, detalles: List<DetalleInforme>): Long {
        return informeDao.insertInformeCompleto(informe, detalles)
    }

    suspend fun deleteInforme(informe: Informe) {
        informeDao.deleteInforme(informe)
    }

    suspend fun getInformesBetween(startDate: Long, endDate: Long): List<InformeConDetalles> {
        return informeDao.getInformesBetweenDates(startDate, endDate)
    }
}
