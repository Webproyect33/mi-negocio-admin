package com.minegocio.admin.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.minegocio.admin.data.dao.*
import com.minegocio.admin.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Producto::class,
        Categoria::class,
        Vendedora::class,
        Informe::class,
        DetalleInforme::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productoDao(): ProductoDao
    abstract fun categoriaDao(): CategoriaDao
    abstract fun vendedoraDao(): VendedoraDao
    abstract fun informeDao(): InformeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mi_negocio_database"
                )
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Seed initial data
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedDatabase(database)
                    }
                }
            }
        }

        private suspend fun seedDatabase(db: AppDatabase) {
            val catDao = db.categoriaDao()
            catDao.insertCategoria(Categoria(nombre = "Bebidas"))
            catDao.insertCategoria(Categoria(nombre = "Abarrotes"))
            catDao.insertCategoria(Categoria(nombre = "Lácteos"))
            catDao.insertCategoria(Categoria(nombre = "Limpieza"))
            catDao.insertCategoria(Categoria(nombre = "Snacks y Dulces"))

            val prodDao = db.productoDao()
            prodDao.insertProducto(Producto(nombre = "Agua Mineral 600ml", precioCompra = 0.50, precioVenta = 1.00, cantidad = 50, categoriaId = 1, formato = "Unidad"))
            prodDao.insertProducto(Producto(nombre = "Gaseosa Cola 2L", precioCompra = 1.80, precioVenta = 2.80, cantidad = 24, categoriaId = 1, formato = "Unidad"))
            prodDao.insertProducto(Producto(nombre = "Arroz Extra 1kg", precioCompra = 0.90, precioVenta = 1.40, cantidad = 40, categoriaId = 2, formato = "Paquete"))
            prodDao.insertProducto(Producto(nombre = "Aceite Vegetal 900ml", precioCompra = 2.20, precioVenta = 3.20, cantidad = 15, categoriaId = 2, formato = "Unidad"))

            val vendDao = db.vendedoraDao()
            vendDao.insertVendedora(Vendedora(nombre = "María González", contrasena = "maria123"))
            vendDao.insertVendedora(Vendedora(nombre = "Rosa Martínez", contrasena = "rosa2026"))
        }
    }
}
