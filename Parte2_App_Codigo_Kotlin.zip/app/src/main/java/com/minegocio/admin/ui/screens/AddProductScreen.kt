package com.minegocio.admin.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minegocio.admin.data.entity.Categoria
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductScreen(
    categorias: List<Categoria>,
    onSaveProduct: (
        nombre: String,
        precioCompra: String,
        precioVenta: String,
        cantidad: String,
        categoriaId: Int?,
        formato: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) -> Unit,
    onNavigateBack: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var nombre by remember { mutableStateOf("") }
    var precioCompra by remember { mutableStateOf("") }
    var precioVenta by remember { mutableStateOf("") }
    var cantidad by remember { mutableStateOf("") }

    var selectedCategoria by remember { mutableStateOf<Categoria?>(null) }
    var isCategoriaExpanded by remember { mutableStateOf(false) }

    val formatos = listOf("Unidad", "Caja", "Paquete", "Docena", "Otro")
    var selectedFormato by remember { mutableStateOf(formatos[0]) }
    var isFormatoExpanded by remember { mutableStateOf(false) }

    var showError by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Agregar Producto Nuevo", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D47A1),
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Nombre
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre del producto *") },
                isError = showError && nombre.isBlank(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            // Precios en fila
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = precioCompra,
                    onValueChange = { precioCompra = it },
                    label = { Text("P. Compra ($) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = showError && precioCompra.isBlank(),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = precioVenta,
                    onValueChange = { precioVenta = it },
                    label = { Text("P. Venta ($) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = showError && precioVenta.isBlank(),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )
            }

            // Cantidad
            OutlinedTextField(
                value = cantidad,
                onValueChange = { cantidad = it },
                label = { Text("Cantidad disponible *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = showError && cantidad.isBlank(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            // Categoría Dropdown (ExposedDropdownMenuBox)
            ExposedDropdownMenuBox(
                expanded = isCategoriaExpanded,
                onExpandedChange = { isCategoriaExpanded = !isCategoriaExpanded }
            ) {
                OutlinedTextField(
                    value = selectedCategoria?.nombre ?: "Seleccionar Categoría",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Categoría *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCategoriaExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    isError = showError && selectedCategoria == null
                )
                ExposedDropdownMenu(
                    expanded = isCategoriaExpanded,
                    onDismissRequest = { isCategoriaExpanded = false }
                ) {
                    if (categorias.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No hay categorías. Crea una primero.") },
                            onClick = { isCategoriaExpanded = false }
                        )
                    } else {
                        categorias.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.nombre) },
                                onClick = {
                                    selectedCategoria = cat
                                    isCategoriaExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Formato Dropdown
            ExposedDropdownMenuBox(
                expanded = isFormatoExpanded,
                onExpandedChange = { isFormatoExpanded = !isFormatoExpanded }
            ) {
                OutlinedTextField(
                    value = selectedFormato,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Formato *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isFormatoExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                ExposedDropdownMenu(
                    expanded = isFormatoExpanded,
                    onDismissRequest = { isFormatoExpanded = false }
                ) {
                    formatos.forEach { fmt ->
                        DropdownMenuItem(
                            text = { Text(fmt) },
                            onClick = {
                                selectedFormato = fmt
                                isFormatoExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Botón Guardar
            Button(
                onClick = {
                    showError = true
                    onSaveProduct(
                        nombre,
                        precioCompra,
                        precioVenta,
                        cantidad,
                        selectedCategoria?.id,
                        selectedFormato,
                        {
                            scope.launch {
                                snackbarHostState.showSnackbar("Producto guardado exitosamente")
                            }
                            nombre = ""
                            precioCompra = ""
                            precioVenta = ""
                            cantidad = ""
                            selectedCategoria = null
                            showError = false
                        },
                        { msg ->
                            scope.launch {
                                snackbarHostState.showSnackbar(msg)
                            }
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B))
            ) {
                Text("Guardar Producto", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
