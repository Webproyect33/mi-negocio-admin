package com.minegocio.admin.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minegocio.admin.data.entity.InformeConDetalles
import com.minegocio.admin.data.entity.Vendedora
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SacarCuentasScreen(
    informes: List<InformeConDetalles>,
    vendedoras: List<Vendedora>
) {
    val context = LocalContext.current
    val calendar = Calendar.currentOrNow()

    // Filtros
    var selectedVendedoraId by remember { mutableStateOf<Int?>(null) } // null = Todas
    var isVendedoraDropdownOpen by remember { mutableStateOf(false) }

    // Rango de fechas (por defecto: últimos 30 días)
    var diasAtras by remember { mutableStateOf(30) }

    // Resultados calculados
    var totalGeneral by remember { mutableStateOf(0.0) }
    var desgloseVendedoras by remember { mutableStateOf<List<Pair<String, Double>>>(emptyList()) }
    var desgloseProductos by remember { mutableStateOf<List<Triple<String, Int, Double>>>(emptyList()) }
    var fueCalculado by remember { mutableStateOf(false) }

    fun calcular() {
        val cutoff = System.currentTimeMillis() - (diasAtras.toLong() * 24 * 60 * 60 * 1000)
        val filtered = informes.filter { item ->
            val matchesDate = item.informe.fecha >= cutoff
            val matchesVendedora = selectedVendedoraId == null || item.informe.vendedoraId == selectedVendedoraId
            matchesDate && matchesVendedora
        }

        val total = filtered.sumOf { it.informe.total }
        totalGeneral = total

        // Desglose por Vendedora
        val porVendedora = filtered.groupBy { it.informe.vendedoraNombre }
            .map { (nombre, list) -> Pair(nombre, list.sumOf { it.informe.total }) }
            .sortedByDescending { it.second }
        desgloseVendedoras = porVendedora

        // Desglose por Producto
        val todosLosDetalles = filtered.flatMap { it.detalles }
        val porProducto = todosLosDetalles.groupBy { it.productoNombre }
            .map { (prod, list) ->
                val cant = list.sumOf { it.cantidad }
                val monto = list.sumOf { it.precioUnitario * it.cantidad }
                Triple(prod, cant, monto)
            }
            .sortedByDescending { it.third }
        desgloseProductos = porProducto

        fueCalculado = true
    }

    // Calcular inicialmente
    LaunchedEffect(informes, vendedoras) {
        calcular()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sacar Cuentas", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D47A1),
                    titleContentColor = Color.White
                ),
                actions = {
                    if (fueCalculado) {
                        IconButton(onClick = {
                            compartirResumen(context, totalGeneral, desgloseVendedoras, desgloseProductos)
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Exportar", tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Filtros Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Filtros de Período y Vendedora",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D47A1),
                        fontSize = 16.sp
                    )

                    // Filtro Vendedora
                    ExposedDropdownMenuBox(
                        expanded = isVendedoraDropdownOpen,
                        onExpandedChange = { isVendedoraDropdownOpen = !isVendedoraDropdownOpen }
                    ) {
                        val currentText = if (selectedVendedoraId == null) "Todas las vendedoras"
                        else vendedoras.find { it.id == selectedVendedoraId }?.nombre ?: "Todas"

                        OutlinedTextField(
                            value = currentText,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Filtrar por Vendedora") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isVendedoraDropdownOpen) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = isVendedoraDropdownOpen,
                            onDismissRequest = { isVendedoraDropdownOpen = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Todas las vendedoras") },
                                onClick = {
                                    selectedVendedoraId = null
                                    isVendedoraDropdownOpen = false
                                }
                            )
                            vendedoras.forEach { v ->
                                DropdownMenuItem(
                                    text = { Text(v.nombre) },
                                    onClick = {
                                        selectedVendedoraId = v.id
                                        isVendedoraDropdownOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // Selector de Período
                    Text(text = "Rango de Fecha: Últimos $diasAtras días", fontSize = 13.sp, color = Color.Gray)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(7 to "7 días", 15 to "15 días", 30 to "30 días", 90 to "3 meses").forEach { (dias, label) ->
                            FilterChip(
                                selected = diasAtras == dias,
                                onClick = { diasAtras = dias },
                                label = { Text(label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Button(
                        onClick = { calcular() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B))
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Calcular Cuentas", fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (fueCalculado) {
                // Card de Total General
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF082A61)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TOTAL GENERAL VENDIDO",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFB0BEC5)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$ ${String.format("%.2f", totalGeneral)}",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF00E676)
                        )
                    }
                }

                // Desglose por Vendedora
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Desglose por Vendedora",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        if (desgloseVendedoras.isEmpty()) {
                            Text("No hay ventas registradas en este período.", color = Color.Gray)
                        } else {
                            desgloseVendedoras.forEach { (nombre, total) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = nombre, fontWeight = FontWeight.Medium, color = Color(0xFF334155))
                                    Text(
                                        text = "$ ${String.format("%.2f", total)}",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF00897B)
                                    )
                                }
                            }
                        }
                    }
                }

                // Desglose por Producto
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Desglose por Producto Vendido",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        if (desgloseProductos.isEmpty()) {
                            Text("Sin datos de productos.", color = Color.Gray)
                        } else {
                            desgloseProductos.forEach { (prod, cant, monto) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = prod, fontWeight = FontWeight.Medium, color = Color(0xFF1E293B))
                                        Text(text = "$cant unidades vendidas", fontSize = 12.sp, color = Color.Gray)
                                    }
                                    Text(
                                        text = "$ ${String.format("%.2f", monto)}",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0D47A1)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun compartirResumen(
    context: Context,
    total: Double,
    vendedoras: List<Pair<String, Double>>,
    productos: List<Triple<String, Int, Double>>
) {
    val sb = StringBuilder()
    sb.appendLine("📊 REPORTE DE CUENTAS - MI NEGOCIO ADMIN")
    sb.appendLine("Fecha: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}")
    sb.appendLine("----------------------------------------")
    sb.appendLine("TOTAL GENERAL VENDIDO: $${String.format("%.2f", total)}")
    sb.appendLine("
DESGLOSE POR VENDEDORA:")
    vendedoras.forEach { (nombre, subtotal) ->
        sb.appendLine("• $nombre: $${String.format("%.2f", subtotal)}")
    }
    sb.appendLine("
DESGLOSE POR PRODUCTOS:")
    productos.forEach { (prod, cant, monto) ->
        sb.appendLine("• $prod: $cant uds | $${String.format("%.2f", monto)}")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Reporte Mi Negocio Admin")
        putExtra(Intent.EXTRA_TEXT, sb.toString())
    }
    context.startActivity(Intent.createChooser(intent, "Exportar Resumen de Cuentas"))
}

private fun Calendar.Companion.currentOrNow(): Calendar = Calendar.getInstance()
