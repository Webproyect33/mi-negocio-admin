package com.minegocio.admin.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF0D47A1)
val BlueDark = Color(0xFF082A61)
val TealAccent = Color(0xFF00897B)
val GreenSuccess = Color(0xFF00E676)
val RedDanger = Color(0xFFD32F2F)

val SlateBackground = Color(0xFFF8FAFC)
val SlateSurface = Color(0xFFFFFFFF)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF475569)
